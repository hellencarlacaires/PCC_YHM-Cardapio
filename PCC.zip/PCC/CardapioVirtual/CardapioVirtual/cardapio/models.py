from django.db import models
from django.contrib.auth import get_user_model
from restaurante.models import Restaurante

# Create your models here.
class Cardapio(models.Model):
    Nome = models.CharField(max_length= 100, null=True, blank=False)
    slogan = models.CharField(max_length=1000, blank=False, null=True)
    Imagem = models.ImageField(upload_to='uploads/', null=True, blank=False)
    Created_at = models.DateTimeField(auto_now_add = True, null=True)
    Updated_at = models.DateTimeField(auto_now = True, null=True)
    Restaurante = models.ForeignKey(Restaurante, on_delete=models.PROTECT, related_name='Restaurante')
    user = models.OneToOneField(get_user_model(), on_delete=models.CASCADE)