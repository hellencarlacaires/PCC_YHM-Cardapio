from django import forms 
from .models import Cardapio

class Cardapio_form(forms.ModelForm):
    class Meta:
        model= Cardapio
        fields = ('Nome', 'Restaurante', 'slogan', 'Imagem')

class Editar_cardapio_form(forms.ModelForm):
    class Meta:
        model= Cardapio
        fields = ('Nome', 'slogan', 'Imagem')