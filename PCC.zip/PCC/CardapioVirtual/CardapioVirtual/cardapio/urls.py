from django.urls import include, path
from . import views
 

urlpatterns = [
    path('criar/<int:id>', views.criar_cardapio, name='criar_cardapio'),
    path('listar/', views.listar_cardapios, name='listar_cardapios'),
    path('detalhar/<int:id>', views.detalhe_cardapio, name='detalhe_cardapio'), 
    path('detalhar/meu_cardapio/<int:id>', views.detalhe_meu_cardapio, name='detalhe_meu_cardapio'), 
    path('editar/<int:id>', views.editar, name='editar'), 
    path('deletar/<int:id>', views.deletar_cardapio, name='deletar_cardapio')
]
