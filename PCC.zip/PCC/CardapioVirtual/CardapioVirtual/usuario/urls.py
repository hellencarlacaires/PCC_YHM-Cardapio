from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('cadastrar/', views.cadastro.as_view(), name='cadastro'),
    path('login/',include('django.contrib.auth.urls')),
]
