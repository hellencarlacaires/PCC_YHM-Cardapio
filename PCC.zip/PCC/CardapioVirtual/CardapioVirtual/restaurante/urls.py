from django.urls import include, path
from . import views

urlpatterns = [
    path('criar/', views.criar, name='criar'),
    path('listar/', views.listar, name='listar'),
    path('detalhar/<int:id>', views.detalhe, name='detalhe'), 
    path('detalhar/meu_restaurante/<int:id>', views.detalhe_meu_restaurante, name='detalhe_meu_restaurante'), 
    path('editar/<int:id>', views.editar, name='editar'), 
    path('deletar/<int:id>', views.deletar, name='deletar'), 
    path('home/', views.home_restaurante, name='home_restaurante'),
    path('template/', views.template, name="template")
]
