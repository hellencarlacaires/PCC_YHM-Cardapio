from django import forms 
from .models import Restaurante

class Restaurante_form(forms.ModelForm):
    class Meta:
        model= Restaurante
        fields = ('Nome', 'Razão_social', 'CPF_CNPJ', 'Telefone_contato', 'Email')