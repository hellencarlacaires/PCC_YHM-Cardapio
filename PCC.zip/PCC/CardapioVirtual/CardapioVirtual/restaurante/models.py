from django.db import models
from django.contrib.auth import get_user_model

class Restaurante(models.Model):
    Nome = models.CharField(max_length = 100, blank=False, null=True)
    Razão_social = models.CharField(max_length = 200, blank=False, null=True)
    CPF_CNPJ = models.CharField(max_length=14, blank=False, null=True)
    Telefone_contato = models.CharField(max_length=15, blank=False, null=True)
    Email = models.CharField(max_length = 50, blank=False, null=True)
    Created_at = models.DateTimeField(auto_now_add = True, null=True)
    Updated_at = models.DateTimeField(auto_now = True, null=True)
    user = models.OneToOneField(get_user_model(), on_delete=models.CASCADE)

   
