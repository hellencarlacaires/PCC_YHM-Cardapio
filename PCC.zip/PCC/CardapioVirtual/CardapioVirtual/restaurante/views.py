from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.urls import reverse
from .forms import Restaurante_form
from .models import Restaurante
from cardapio.models import Cardapio
from cardapio.views import criar_cardapio
# Create your views here.



def template(request):
    return render(request, 'index.html', {})

@login_required
def criar(equest):
    if request.method =='POST':
        form = Restaurante_form(request.POST)

        if form.is_valid():
            restaurante = form.save(commit=False)
            restaurante.user = request.user
            restaurante.save()
            usuario = request.user
            a = get_object_or_404(Restaurante, user= usuario)
            return redirect(reverse('criar_cardapio', args=[a.id]))
    else:
        form = Restaurante_form
        return render(request, 'criar_restaurante.html',{'form': form})

def listar(request):
    Rest = Restaurante.objects.all()

    context={
        'rest': Rest
    }
    return render(request, 'lista_restaurantes.html', context)

def detalhe(request, id):
    Rest = get_object_or_404(Restaurante, pk=id)
    context={
        'rest': Rest
    }
    return render(request, 'detalhes_restaurante.html', context)

@login_required
def detalhe_meu_restaurante(request, id):
    Rest = get_object_or_404(Restaurante, pk=id)
    context={
        'rest': Rest
    }
    return render(request, 'detalhes_meu_restaurante.html', context)

@login_required
def editar(request, id):
    Rest = get_object_or_404(Restaurante, pk=id)
    form = Restaurante_form(instance=Rest)

    context ={
        'form': form, 
        'rest': Rest
    }

    if request.method == 'POST':
        form = Restaurante_form(request.POST, instance=Rest)

        if form.is_valid():
            Rest.save()
            return redirect('/')
        else:
            return render(request, 'editar_restaurante.html', context)   
    else:
        return render(request, 'editar_restaurante.html', context)

@login_required
def deletar(resquest, id):
    Restaurante.objects.get(pk=id).delete()
    return redirect('/')


def home_restaurante(request):
    usuario = request.user
    a = Restaurante.objects.filter(user=usuario)
    if a:
        a = get_object_or_404(Restaurante, user=usuario)
        b = Cardapio.objects.filter(Restaurante=a)
        if b:
            b = get_object_or_404(Cardapio, Restaurante=a)
            context ={
                'restaurante': a, 
                'cardapio': b, 
            }
            return render(request, 'home.html', context)
        else:
            context ={
                'restaurante': a, 
                'cardapio': b, 
            }
            return render(request, 'home_novo_cardapio.html', context)
    else:
        return redirect(reverse('criar'))
        
