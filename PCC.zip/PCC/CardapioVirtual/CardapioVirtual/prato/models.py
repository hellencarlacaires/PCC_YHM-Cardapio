from django.db import models
from django.contrib.auth import get_user_model
from cardapio.models import Cardapio

class Prato(models.Model):
    CATEGORIA = (
        ('Bebidas', 'Bebidas'),
        ('Sobremesas', 'Sobremesas'),
        ('Comidas', 'Comidas')
    )
    Nome = models.CharField(max_length = 100, blank=False, null=True)
    Ingredientes = models.CharField(max_length = 1000, blank=False, null=True)
    Preço = models.FloatField(blank=False, null=True)
    Categoria = models.CharField(max_length = 100, blank=False, null=True, choices = CATEGORIA)
    Cardapio = models.ForeignKey(Cardapio, on_delete=models.CASCADE, related_name='Pratos')
    Created_at = models.DateTimeField(auto_now_add = True, null=True)
    Updated_at = models.DateTimeField(auto_now = True, null=True)