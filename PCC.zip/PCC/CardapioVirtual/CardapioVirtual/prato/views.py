from django.shortcuts import render, get_object_or_404, redirect
from prato.models import Prato
from cardapio.models import Cardapio
from .forms import Novo_item_form, Editar_item_form
from django.urls import reverse
from django.contrib.auth.decorators import login_required
# Create your views here.
@login_required
def novo_item(request, id):    
    b = get_object_or_404(Cardapio, pk=id).id
    if request.method =='POST':
        form = Novo_item_form(request.POST)

        if form.is_valid():
            form.save()
            return redirect(reverse('novo_item', args=[b]))

    else:
        form = Novo_item_form
        a = get_object_or_404(Cardapio, pk=id)
        context= {
            'form':form,
            'cardapio': a
        }
        return render(request, 'novo_item_cardapio.html', context)

@login_required
def editar_item(request, id_cardapio, id_item):
    a = get_object_or_404(Prato, pk=id_item)
    form = Editar_item_form(instance=a)
    b = get_object_or_404(Cardapio, pk=id_cardapio).id

    context ={
        'form': form, 
        'prato': a
    }

    if request.method == 'POST':
        form = Editar_item_form(request.POST, instance=a)

        if form.is_valid():
            a.save()
            return redirect(reverse('detalhe_meu_cardapio', args=[b]))
        else:
            return render(request, 'editar_item.html', context)   
    else:
        return render(request, 'editar_item.html', context)

@login_required
def deletar_item(request, id_cardapio, id_item):
    Prato.objects.get(pk=id_item).delete()
    b = get_object_or_404(Cardapio, pk=id_cardapio).id
    return redirect(reverse('detalhe_meu_cardapio', args=[b]))